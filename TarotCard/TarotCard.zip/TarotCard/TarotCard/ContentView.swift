//
//  ContentView.swift
//  TarotCard
//
//  Created by Jaden Lin on 1/20/23.
//

import SwiftUI


struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

struct ContentView: View {
    var body: some View {
            Text("Click For Fortune")

    }
}

