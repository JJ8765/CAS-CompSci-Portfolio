//
//  CatStruct.swift
//  TarotCard
//
//  Created by Jaden Lin on 1/20/23.
//

import Foundation

let catUrl = "https://cataas.com/cat"

let sampleCat = Cat(image: "image", url: "URL")


struct Cat: Codable {
    var image: String
    var url: String
}

func loadCatData(){

    let apiURL = URL(string: catUrl)!
    let request = URLRequest(url: apiURL)
    let task = URLSession.shared.dataTask(with: request) { data, response, error in
        do{
            if let data = data {
                let dataString = String(data:data, encoding: .utf8)!
                print(dataString)
                let catData = try JSONDecoder().decode(Cat.self, from: data)
              print(catData)
                
            }
        } catch{
            print(error)
        }
    }
    task.resume()
}
