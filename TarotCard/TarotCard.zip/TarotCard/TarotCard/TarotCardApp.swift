//
//  TarotCardApp.swift
//  TarotCard
//
//  Created by Jaden Lin on 1/20/23.
//

import SwiftUI

@main
struct TarotCardApp: App {
    var body: some Scene {
        WindowGroup {
            FortuneView()
        }
    }
}
