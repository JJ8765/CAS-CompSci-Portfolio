//
//  ViewController.swift
//  QuizGame
//
//  Created by Jaden Lin on 10/4/22.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

