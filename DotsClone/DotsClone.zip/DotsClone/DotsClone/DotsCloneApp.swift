//
//  DotsCloneApp.swift
//  DotsClone
//
//  Created by Jaden Lin on 2/28/23.
//

import SwiftUI

@main
struct DotsCloneApp: App {
    var body: some Scene {
        WindowGroup {
            DragView()
        }
    }
}
